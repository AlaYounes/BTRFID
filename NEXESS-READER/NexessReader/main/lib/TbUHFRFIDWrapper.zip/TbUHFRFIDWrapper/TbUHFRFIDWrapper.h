// TbUHFRFIDWrapper.h

#pragma once

using namespace System;

typedef unsigned long DWORD;
typedef void *PVOID;
typedef PVOID HANDLE;
typedef unsigned char BYTE;
typedef unsigned short WORD;

#include "TbUHFRFID.h"

namespace TbUHFRFIDWrapper {
	extern "C"{ // no name decoration

		// funciton to export + no 
		__declspec( dllexport ) DWORD __stdcall openReader(HANDLE *hReader);
		__declspec( dllexport ) DWORD __stdcall closeReader(HANDLE hreader);
		__declspec( dllexport ) DWORD __stdcall getPower(HANDLE hreader, int *rfpower);
		__declspec( dllexport ) DWORD __stdcall setPower(HANDLE hreader, int rfpower);
		__declspec( dllexport ) DWORD __stdcall firstTag(HANDLE hreader, BYTE *pepc, int *pepclen, int *prssi);
		__declspec( dllexport ) DWORD __stdcall nextTag(HANDLE hreader, BYTE *pepc, int *pepclen, int *prssi);
		__declspec( dllexport ) DWORD __stdcall selectTag(HANDLE hreader, BYTE *pepc, int epclen);
		__declspec( dllexport ) DWORD __stdcall readTag(HANDLE hreader, int bank, int address, BYTE *ppasscode, int passcodelen, WORD *pdata, int datalen);
		__declspec( dllexport ) DWORD __stdcall writeTag(HANDLE hreader, int bank, int address, BYTE *ppasscode, int passcodelen, WORD *pdata, int datalen);
		__declspec( dllexport ) DWORD __stdcall killTag(HANDLE hreader, BYTE *ppasscode, int passcodelen);
		__declspec( dllexport ) DWORD __stdcall lockTag(HANDLE hreader, int action, int bank, BYTE *ppasscode, int passcodelen);
	}
}
