// Il s'agit du fichier DLL principal.

#include "stdafx.h"

#include "TbUHFRFIDWrapper.h"

namespace TbUHFRFIDWrapper {


	DWORD __stdcall openReader(HANDLE *hReader){

		return OpenUHFReader(hReader);
	}

	DWORD __stdcall closeReader(HANDLE hreader){

		return CloseUHFReader(hreader);
	}

	DWORD __stdcall getPower(HANDLE hreader, int *rfpower){

		return GetPower(hreader, rfpower);
	}

	DWORD __stdcall setPower(HANDLE hreader, int rfpower){

		return SetPower(hreader, rfpower);
	}

	DWORD __stdcall firstTag(HANDLE hreader, BYTE *pepc, int *pepclen, int *prssi){

		return FirstTag(hreader, pepc, pepclen, prssi);
	}

	DWORD __stdcall nextTag(HANDLE hreader, BYTE *pepc, int *pepclen, int *prssi){

		return NextTag(hreader, pepc, pepclen, prssi);
	}

	DWORD __stdcall selectTag(HANDLE hreader, BYTE *pepc, int epclen){

		return SelectTag(hreader, pepc, epclen);
	}

	DWORD __stdcall readTag(HANDLE hreader, int bank, int address, BYTE *ppasscode, int passcodelen, WORD *pdata, int datalen){

		return ReadTag(hreader, bank, address, ppasscode, passcodelen, pdata, datalen);
	}

	DWORD __stdcall writeTag(HANDLE hreader, int bank, int address, BYTE *ppasscode, int passcodelen, WORD *pdata, int datalen){

		return WriteTag(hreader, bank, address, ppasscode, passcodelen, pdata, datalen);
	}

	DWORD __stdcall killTag(HANDLE hreader, BYTE *ppasscode, int passcodelen){

		return KillTag(hreader, ppasscode, passcodelen);
	}

	DWORD __stdcall lockTag(HANDLE hreader, int action, int bank, BYTE *ppasscode, int passcodelen){

		return LockTag(hreader, action, bank, ppasscode, passcodelen);
	}

}