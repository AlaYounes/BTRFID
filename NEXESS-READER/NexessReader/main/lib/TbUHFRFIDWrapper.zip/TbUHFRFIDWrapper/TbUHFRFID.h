// TbUHFRFID.h : V1.00L10 M10
//
#pragma once

#define UR_OK                      (0x00000000)
#define UR_ERR_UNCLASSIFIED        (0x00000001)
#define UR_ERR_INVALID_HANDLE      (0x00000002)
#define UR_ERR_INVALID_PARAMETER   (0x00000003)
#define UR_ERR_NO_TAGS             (0x00000004)
#define UR_ERR_COMMAND_SEND        (0x00000005)
#define UR_ERR_COMMAND_RECEIVE     (0x00000006)
#define UR_ERR_BUFFERTOOSMALL      (0x00000007)
#define UR_ERR_BUFFERTOOBIG        (0x00000008)
#define UR_ERR_DEVICENOTFOUND      (0x00000009)
#define UR_ERR_SYSTEM              (0x0000000A)
#define UR_ERR_REQ_NOT_ALLOWED     (0x00010001)
#define UR_ERR_ACCESS              (0x00010002)
#define UR_ERR_KILL                (0x00010003)
#define UR_ERR_NOREPLY             (0x00010004)
#define UR_ERR_LOCK                (0x00010005)
#define UR_ERR_WRITE               (0x00010006)
#define UR_ERR_ERASE               (0x00010007)
#define UR_ERR_READ                (0x00010008)
#define UR_ERR_SELECT              (0x00010009)
#define UR_ERR_CHANNEL_TIMEOUT     (0x0001000A)
#define UR_ERR_INVALID_PARAMETER2  (0x0001000F)
#define UR_ERR_EASCODE             (0x00010020)
#define UR_ERR_OTHER               (0x00010080)
#define UR_ERR_MEMORY_OVERRUN      (0x00010083)
#define UR_ERR_MEMORY_LOCKED       (0x00010084)
#define UR_ERR_INSUFFICIENT_POWER  (0x0001008B)
#define UR_ERR_NONSPECIFIC         (0x0001008F)
#define UR_ERR_READONLY_ADDRESS    (0x000100A0)
#define UR_ERR_PCIE_RADIO_DISABLED (0x000100B0)
#define UR_ERR_SECURITY_FAILURE    (0x000100FE)
#define UR_ERR_HW_FAILURE          (0x000100FF)

DWORD OpenUHFReader(HANDLE *hReader);
DWORD CloseUHFReader(HANDLE hReader);
DWORD GetPower(HANDLE hReader, int *RFPower);
DWORD SetPower(HANDLE hReader, int RFPower);
DWORD FirstTag(HANDLE hReader, BYTE *pEPC, int *pEPCLen, int *pRssi);
DWORD NextTag(HANDLE hReader, BYTE *pEPC, int *pEPCLen, int *pRssi);
DWORD SelectTag(HANDLE hReader, BYTE *pEPC, int EPCLen);
DWORD ReadTag(HANDLE hReader, int Bank, int Address, BYTE *pPasscode, int PasscodeLen, WORD *pData, int DataLen);
DWORD WriteTag(HANDLE hReader, int Bank, int Address, BYTE *pPasscode, int PasscodeLen, WORD *pData, int DataLen);
DWORD KillTag(HANDLE hReader, BYTE *pPasscode, int PasscodeLen);
DWORD LockTag(HANDLE hReader, int Action, int Bank, BYTE *pPasscode, int PasscodeLen);

